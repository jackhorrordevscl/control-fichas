--
-- PostgreSQL database dump
--

\restrict 4DJ9qwyeL77JvXn0AaGXODhpnazKcisJ5JnZGVJfKhj718ywNr8yQ5Z5aHnVUeZ

-- Dumped from database version 17.9 (Ubuntu 17.9-0ubuntu0.25.10.1)
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-0ubuntu0.25.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AuditAction; Type: TYPE; Schema: public; Owner: umbral_user
--

CREATE TYPE public."AuditAction" AS ENUM (
    'LOGIN',
    'LOGOUT',
    'VIEW',
    'CREATE',
    'UPDATE',
    'SOFT_DELETE',
    'EXPORT_PDF',
    'DOCUMENT_UPLOAD',
    'MFA_ENABLED',
    'MFA_FAILED'
);


ALTER TYPE public."AuditAction" OWNER TO umbral_user;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: umbral_user
--

CREATE TYPE public."DocumentType" AS ENUM (
    'INFORMED_CONSENT',
    'TELEMED_AGREEMENT',
    'PATIENT_REPORT',
    'OTHER'
);


ALTER TYPE public."DocumentType" OWNER TO umbral_user;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: umbral_user
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'THERAPIST'
);


ALTER TYPE public."Role" OWNER TO umbral_user;

--
-- Name: SessionType; Type: TYPE; Schema: public; Owner: umbral_user
--

CREATE TYPE public."SessionType" AS ENUM (
    'IN_PERSON',
    'TELEMED'
);


ALTER TYPE public."SessionType" OWNER TO umbral_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text NOT NULL,
    action public."AuditAction" NOT NULL,
    resource text NOT NULL,
    "resourceId" text NOT NULL,
    detail text,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO umbral_user;

--
-- Name: Consultation; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."Consultation" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "therapistId" text NOT NULL,
    "sessionDate" timestamp(3) without time zone NOT NULL,
    "consultReason" text NOT NULL,
    intervention text NOT NULL,
    agreements text,
    "nextSessionDate" timestamp(3) without time zone,
    "sessionType" public."SessionType" DEFAULT 'IN_PERSON'::public."SessionType" NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "previousVersionId" text,
    "isCorrected" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Consultation" OWNER TO umbral_user;

--
-- Name: Patient; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."Patient" (
    id text NOT NULL,
    "fullName" text NOT NULL,
    rut text NOT NULL,
    "birthDate" timestamp(3) without time zone NOT NULL,
    occupation text,
    address text,
    phone text,
    email text,
    "emergencyContactName" text,
    "emergencyContactPhone" text,
    "treatingPsychiatrist" text,
    "treatingDoctor" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "consentSigned" boolean DEFAULT false NOT NULL,
    "telemedConsentSigned" boolean DEFAULT false NOT NULL,
    "therapistId" text NOT NULL
);


ALTER TABLE public."Patient" OWNER TO umbral_user;

--
-- Name: PatientDocument; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."PatientDocument" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    type public."DocumentType" NOT NULL,
    "fileName" text NOT NULL,
    "storagePath" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "uploadedBy" text NOT NULL
);


ALTER TABLE public."PatientDocument" OWNER TO umbral_user;

--
-- Name: User; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    name text NOT NULL,
    role public."Role" DEFAULT 'THERAPIST'::public."Role" NOT NULL,
    "mfaSecret" text,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."User" OWNER TO umbral_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO umbral_user;

--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."AuditLog" (id, "userId", action, resource, "resourceId", detail, "ipAddress", "userAgent", "createdAt") FROM stdin;
7cf3ed63-cdbe-4b29-af68-6a0c62c02798	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:06.781
63d131d6-c3f0-4672-bb9a-2605d38ca0c7	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:06.793
764ffc9c-9ea9-4e24-bce2-6fd5d591ffdd	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:10.685
679e4f79-4c5d-4be9-a7d9-755125fde464	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:11.173
ce7e5f83-1fdb-4b69-9da2-b76bf8ac164b	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:12.511
76467a3d-5210-44b0-a177-40a7b92d626b	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:40.969
a50361a3-9543-458e-a4cf-20a8f534ddd0	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:51.682
6be7d787-8d6f-4d42-bfec-2dbf3de85941	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:55.778
a79e30a7-b1f6-46c0-92f4-7e043980a9cc	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:55.78
1614b098-1711-4d5f-afc4-7b5d87d38b87	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:34:58.968
527b5aa4-bd14-49c8-92b6-9797efa6aa12	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:35:04.13
c3947c20-e0e0-4f34-b3a8-c20f7b597c6e	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	CREATE	MFA	N/A	POST /api/v1/auth/mfa/generate	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:35:09.609
f6153f3d-38f7-4f15-92af-fb30f78d99c7	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:35:11.621
2e9f2edb-d59f-4c53-b407-41e9588f7168	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:35:14.142
1073a1c9-8729-41bc-ba14-652cf1783a2d	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:35:14.144
5cf66f4a-28b1-4510-8864-3445c1c6ed06	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:36:07.572
e0b75005-6863-4c14-a2d9-8a210a05a3c3	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:36:07.574
6d5e0441-9199-404f-9de2-4014287ea708	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:41:12.757
c9921655-347a-4452-af98-278acdeb708f	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:41:12.758
3a614961-2da9-44e2-8bec-15378b13470e	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:44:07.14
66be779d-9b1f-44c9-8e2a-33579b1d401c	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:44:07.137
44694ec6-d6db-4591-9066-0d4123e587c1	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:44:11.57
7ce21dfb-75a2-47a6-b63f-d57950efe6b1	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:46:33.211
d81c9490-9620-405d-b929-62506cccc062	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	CREATE	MFA	N/A	POST /api/v1/auth/mfa/generate	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:46:37.643
20d8de2b-c808-474b-8c15-d49de2da50fe	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	CREATE	MFA	N/A	POST /api/v1/auth/mfa/enable	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:46:51.363
4a44dc0c-d42d-4859-9b93-dbdc347e5012	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:46:56.461
5584fa90-916e-405a-b214-8d00a2a9bccb	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:46:57.736
8fa51125-c0c0-4c78-8be6-43c15f31d0c4	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:46:57.739
eaaea202-89b8-4e51-9b52-dc1b5bc93521	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:46:58.286
808dbeb4-eea3-47eb-90d1-626fc3e26beb	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:46:58.625
a68043c5-f797-4011-84ee-2aeb51c57baf	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:47:01.52
a44b06a5-e0c7-42e7-aa08-96435fc69c5f	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	CREATE	Unknown	N/A	POST /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:47:27.573
f3d8674b-8f85-45a7-8467-96009c2be20b	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:47:27.579
ea3d645d-7158-45c8-a7d4-2f35c6dfc364	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:47:33.662
bfae17a7-86e2-4bf1-a43b-e87336890589	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:47:33.663
a9879ac5-bf2d-4ba0-8f9f-fa8fe31a2038	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:47:34.389
2eab2f1e-4e6b-492a-be40-c9bf3b2c4fbb	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:47:35.228
994b2aa8-8b50-4ec5-958b-e08b9e9e90de	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:48:26.368
97cfe83b-b2f6-4ab3-b2f9-e58056ebb264	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:49:50.705
1086d024-8416-416d-b61b-c5b68e2c8b29	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:49:51.73
093f9238-1524-46fb-a860-f81a61c43706	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:49:54.912
07c0adc8-ad58-4919-81c6-12f219cf3d7d	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:49:54.913
a517e4e6-db49-4532-8ac7-01d98c45999f	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:11.939
a679bd16-ef7e-4fa4-9887-4a022ae7680f	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:11.94
4ff95d63-81d9-43a0-a731-70461ba73abd	2e75eb36-128c-49a9-86cf-aca3cfc53e02	CREATE	MFA	N/A	POST /api/v1/auth/mfa/generate	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:14.257
a1628979-dd0c-430c-abce-f4280f25ee27	2e75eb36-128c-49a9-86cf-aca3cfc53e02	CREATE	MFA	N/A	POST /api/v1/auth/mfa/enable	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:30.51
8b66549e-acf8-40d2-aebd-c03ce601dafd	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:32.124
02d0148d-2437-4276-8783-c8656e5c5fa1	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:32.126
2edb7338-510f-4675-a3a1-1772c346a847	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:35.001
36999983-6b69-4dc2-ac0e-0ed02c0f4ba6	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:44.47
47f778cc-529d-471f-afe6-4f2a10f38fc1	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:50:59.049
8735c1cb-eeae-4427-96bc-1f3b70f896b5	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:53:29.28
72e6ac40-e53a-4d95-b9dc-023919947c67	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:54:52.904
704f41ac-eaa0-444b-94b9-f3502f4f71ae	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:54:59.862
02115d38-9e7d-47ea-a650-0495f3e4337b	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:55:13.07
1d3fe3a0-770f-456c-ac8a-fecb04aa2819	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:55:13.842
f27a21a8-3d57-4041-9636-02b5889ea8be	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:55:15.76
e93c014e-e2cc-4403-ba70-fe8898484bdc	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:57:05.277
08803324-204a-47be-a491-2d701b29bb38	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:57:29.707
37710d68-1986-4cfe-8db5-49badfdad8b9	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:57:29.705
73464086-7f41-4f1f-a2de-330f43f27a94	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Unknown	N/A	GET /api/v1/users	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:57:31.044
eacdad88-a501-47a5-8940-a8d0aac06743	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:57:35.523
4bcda28c-4502-419c-87fb-3541d3c282e9	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:57:39.246
239fb5d0-efb7-41a4-9af9-ae81625e79b6	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 03:57:49.179
f9917705-b0e4-421c-8d65-ecd64af8a321	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:00:54.733
02cf35f8-3bfd-491f-8ae1-ce4738904891	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	CREATE	Patient	N/A	POST /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:02:16.55
c45c4107-71c5-4d7c-bb9a-6d2fdb21570e	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:02:16.557
207c8dca-ad71-482c-9927-6faa66113064	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	SOFT_DELETE	Patient	a99907a8-2d3a-4a17-8afc-afe2e912a3c1	DELETE /api/v1/patients/a99907a8-2d3a-4a17-8afc-afe2e912a3c1	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:02:27.236
e5601722-904e-4dc8-ab04-639d299f5caa	e38afd34-b96e-4a3c-8bad-d5ca66854c4b	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:02:27.243
c8380796-970a-462f-ae95-f9882996043b	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:02:38.654
5e16aecf-c174-4213-9df9-338a56ad7172	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:02:38.67
169cf5b5-1a06-43a4-833e-e2ee17991066	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:02:42.669
ee6ffbef-f65c-4fb5-9d56-2220ed0deb6f	2e75eb36-128c-49a9-86cf-aca3cfc53e02	CREATE	Patient	N/A	POST /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:03:47.547
1869f53b-bcb8-4a8a-8a39-eddbd2e7bd6b	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:03:47.555
887ff27c-bb37-489e-ba03-a74b54d853c5	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:04:00.426
dd1be1dd-f3af-4ef9-8eaa-126a2b59c5b5	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Consultation	46641780-7338-4013-a784-165a5111abce	GET /api/v1/consultations/patient/46641780-7338-4013-a784-165a5111abce	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:04:01.526
ab7fcc86-6767-44b6-a77c-5ddc7d71e74b	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:04:57.833
17e58040-9d04-4f09-a115-4b8bdb6f5fa6	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:04:57.848
2f37ad0f-3c76-4867-b87d-b4b0506674c4	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Consultation	46641780-7338-4013-a784-165a5111abce	GET /api/v1/consultations/patient/46641780-7338-4013-a784-165a5111abce	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:04:57.858
13c5f505-0488-4078-8413-6846907f05ec	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:05:01.031
7a5cbf77-b627-469c-a468-42be17e11b67	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Unknown	46641780-7338-4013-a784-165a5111abce	GET /api/v1/documents/patient/46641780-7338-4013-a784-165a5111abce	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:05:02.572
08c15f59-7115-4ca9-9a2c-3386b2a37426	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:05:13.777
4e52f5c9-c2bd-4c5b-ba5c-4d48f22fbb05	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Consultation	46641780-7338-4013-a784-165a5111abce	GET /api/v1/consultations/patient/46641780-7338-4013-a784-165a5111abce	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:05:14.303
efb546c1-552b-475b-b4f6-2c0a5a4b48c5	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:05:15.52
5bcdd39d-b657-4a39-8ca6-8a8766a37e30	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Unknown	46641780-7338-4013-a784-165a5111abce	GET /api/v1/documents/patient/46641780-7338-4013-a784-165a5111abce	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:05:16.958
aef8c7ff-4037-4a9c-a21c-81f7d64fdb23	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:05:54.866
0aa4ffd4-6935-4c1a-9a78-12c471ea9173	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:17:32.637
4a1d24e7-4fc4-4920-9796-d9240c42fc32	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:17:58.486
edb6b223-2bbb-4d1c-9d72-98041a9dd3d3	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:43:58.077
679aa1f7-711b-4600-a2dd-355bb256aedd	2e75eb36-128c-49a9-86cf-aca3cfc53e02	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-06 04:55:00.385
\.


--
-- Data for Name: Consultation; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."Consultation" (id, "patientId", "therapistId", "sessionDate", "consultReason", intervention, agreements, "nextSessionDate", "sessionType", version, "previousVersionId", "isCorrected", "createdAt") FROM stdin;
\.


--
-- Data for Name: Patient; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."Patient" (id, "fullName", rut, "birthDate", occupation, address, phone, email, "emergencyContactName", "emergencyContactPhone", "treatingPsychiatrist", "treatingDoctor", "isActive", "deletedAt", "createdAt", "updatedAt", "consentSigned", "telemedConsentSigned", "therapistId") FROM stdin;
a99907a8-2d3a-4a17-8afc-afe2e912a3c1	Juan Jose Martinez Correa	176619899	1990-08-02 00:00:00	Developer	Direccion	+56956039666	correo@correo.cl	Contacto Emergencia	+56123456789	-		t	2026-03-06 04:02:27.232	2026-03-06 04:02:16.545	2026-03-06 04:02:27.233	f	f	e38afd34-b96e-4a3c-8bad-d5ca66854c4b
46641780-7338-4013-a784-165a5111abce	Juan Martinez	17.661.989-9	1990-01-01 00:00:00	DevOps	Direccion 1234	+56912345678	correo@correo.com	Contacto	+56987654321			t	\N	2026-03-06 04:03:47.542	2026-03-06 04:03:47.542	f	f	2e75eb36-128c-49a9-86cf-aca3cfc53e02
\.


--
-- Data for Name: PatientDocument; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."PatientDocument" (id, "patientId", type, "fileName", "storagePath", "uploadedAt", "uploadedBy") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."User" (id, email, "passwordHash", name, role, "mfaSecret", "mfaEnabled", "createdAt", "updatedAt", "deletedAt") FROM stdin;
e38afd34-b96e-4a3c-8bad-d5ca66854c4b	admin@umbral.cl	$argon2id$v=19$m=65536,t=3,p=4$cWYi9elg6fOEmDajFbQhvQ$o1CXc4nUfcnLsRzOg/Lv/ZsxrFsQISnUgZVJI4+1PDA	Administrador Umbral	ADMIN	OY2UARRILBKUURZTMRFD4WR6PVRXWRRK	t	2026-03-06 03:31:55.248	2026-03-06 03:46:51.359	\N
2e75eb36-128c-49a9-86cf-aca3cfc53e02	mvera@umbral.cl	$argon2id$v=19$m=65536,t=3,p=4$X/tG+0pXDQxMWKy/4iHxiw$UXJys63T8DVsioWnvmR8OEUF7c0lR0pnLIatiGuWilg	Marina Vera Guzman	THERAPIST	EQ7DATRTFJIWCQRRHQ4SMZBWKRQUYPZZ	t	2026-03-06 03:47:27.568	2026-03-06 03:50:30.506	\N
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
c9298969-cd00-43b4-bbc8-50fde5959d27	1c734e4e9677154f01f7ae28be0471607f774ac0367e366f6cc1bd029b52863c	2026-03-06 00:30:31.495997-03	20260305123950_init	\N	\N	2026-03-06 00:30:31.480066-03	1
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Consultation Consultation_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Consultation"
    ADD CONSTRAINT "Consultation_pkey" PRIMARY KEY (id);


--
-- Name: PatientDocument PatientDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."PatientDocument"
    ADD CONSTRAINT "PatientDocument_pkey" PRIMARY KEY (id);


--
-- Name: Patient Patient_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Patient_rut_key; Type: INDEX; Schema: public; Owner: umbral_user
--

CREATE UNIQUE INDEX "Patient_rut_key" ON public."Patient" USING btree (rut);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: umbral_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Consultation Consultation_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Consultation"
    ADD CONSTRAINT "Consultation_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Consultation Consultation_therapistId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Consultation"
    ADD CONSTRAINT "Consultation_therapistId_fkey" FOREIGN KEY ("therapistId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PatientDocument PatientDocument_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."PatientDocument"
    ADD CONSTRAINT "PatientDocument_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Patient Patient_therapistId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_therapistId_fkey" FOREIGN KEY ("therapistId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict 4DJ9qwyeL77JvXn0AaGXODhpnazKcisJ5JnZGVJfKhj718ywNr8yQ5Z5aHnVUeZ

