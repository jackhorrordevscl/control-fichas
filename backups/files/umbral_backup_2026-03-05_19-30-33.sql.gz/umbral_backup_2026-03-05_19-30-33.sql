--
-- PostgreSQL database dump
--

\restrict k29X0byOep5upk9izSFmDPZI9NGI1gWYrAu6joR5ZOZY6fQjxooLuOC0hQeSCMf

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AuditAction; Type: TYPE; Schema: public; Owner: umbral_user
--

CREATE TYPE public."AuditAction" AS ENUM (
    'LOGIN',
    'LOGOUT',
    'VIEW',
    'CREATE',
    'UPDATE',
    'SOFT_DELETE',
    'EXPORT_PDF',
    'DOCUMENT_UPLOAD',
    'MFA_ENABLED',
    'MFA_FAILED'
);


ALTER TYPE public."AuditAction" OWNER TO umbral_user;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: umbral_user
--

CREATE TYPE public."DocumentType" AS ENUM (
    'INFORMED_CONSENT',
    'TELEMED_AGREEMENT',
    'PATIENT_REPORT',
    'OTHER'
);


ALTER TYPE public."DocumentType" OWNER TO umbral_user;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: umbral_user
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'THERAPIST'
);


ALTER TYPE public."Role" OWNER TO umbral_user;

--
-- Name: SessionType; Type: TYPE; Schema: public; Owner: umbral_user
--

CREATE TYPE public."SessionType" AS ENUM (
    'IN_PERSON',
    'TELEMED'
);


ALTER TYPE public."SessionType" OWNER TO umbral_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text NOT NULL,
    action public."AuditAction" NOT NULL,
    resource text NOT NULL,
    "resourceId" text NOT NULL,
    detail text,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO umbral_user;

--
-- Name: Consultation; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."Consultation" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    "therapistId" text NOT NULL,
    "sessionDate" timestamp(3) without time zone NOT NULL,
    "consultReason" text NOT NULL,
    intervention text NOT NULL,
    agreements text,
    "nextSessionDate" timestamp(3) without time zone,
    "sessionType" public."SessionType" DEFAULT 'IN_PERSON'::public."SessionType" NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    "previousVersionId" text,
    "isCorrected" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Consultation" OWNER TO umbral_user;

--
-- Name: Patient; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."Patient" (
    id text NOT NULL,
    "fullName" text NOT NULL,
    rut text NOT NULL,
    "birthDate" timestamp(3) without time zone NOT NULL,
    occupation text,
    address text,
    phone text,
    email text,
    "emergencyContactName" text,
    "emergencyContactPhone" text,
    "treatingPsychiatrist" text,
    "treatingDoctor" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "consentSigned" boolean DEFAULT false NOT NULL,
    "telemedConsentSigned" boolean DEFAULT false NOT NULL,
    "therapistId" text NOT NULL
);


ALTER TABLE public."Patient" OWNER TO umbral_user;

--
-- Name: PatientDocument; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."PatientDocument" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    type public."DocumentType" NOT NULL,
    "fileName" text NOT NULL,
    "storagePath" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "uploadedBy" text NOT NULL
);


ALTER TABLE public."PatientDocument" OWNER TO umbral_user;

--
-- Name: User; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    name text NOT NULL,
    role public."Role" DEFAULT 'THERAPIST'::public."Role" NOT NULL,
    "mfaSecret" text,
    "mfaEnabled" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public."User" OWNER TO umbral_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: umbral_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO umbral_user;

--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."AuditLog" (id, "userId", action, resource, "resourceId", detail, "ipAddress", "userAgent", "createdAt") FROM stdin;
7dccd3c7-9547-4b9f-a361-6fe490a26c5c	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:05.019
11d6b3cc-2cf4-443f-bae7-d17119e8e80c	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:05.036
84e0cb97-73ad-4c4a-bfb2-cc4390f413cf	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Consultation	fd5ef203-02a1-48fb-8bb3-2870633d6ec8	GET /api/v1/consultations/patient/fd5ef203-02a1-48fb-8bb3-2870633d6ec8	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:05.041
5259d5b0-de5a-40da-9503-fbb25dd8125d	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Consultation	43cefa78-2ba1-479e-b174-b69e044c57ef	GET /api/v1/consultations/patient/43cefa78-2ba1-479e-b174-b69e044c57ef	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:05.056
edb323e9-f87f-48ce-9481-6ec7ca65ec11	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Consultation	f52e851d-0603-4de0-8277-d3f49ff10246	GET /api/v1/consultations/patient/f52e851d-0603-4de0-8277-d3f49ff10246	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:05.058
531e447a-1931-43fe-a3e0-3daaef912f7e	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:31.151
44c9eede-f1d1-485a-a722-89f528c3d55d	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:31.155
29827614-4894-4640-a46c-cf5ab76a3498	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Consultation	fd5ef203-02a1-48fb-8bb3-2870633d6ec8	GET /api/v1/consultations/patient/fd5ef203-02a1-48fb-8bb3-2870633d6ec8	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:31.168
0c6ee30f-dfc0-4e06-ab58-e7f5c6fd52d8	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Consultation	f52e851d-0603-4de0-8277-d3f49ff10246	GET /api/v1/consultations/patient/f52e851d-0603-4de0-8277-d3f49ff10246	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:31.17
364049cd-d7e1-4992-8eeb-22a08cbc2504	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Consultation	43cefa78-2ba1-479e-b174-b69e044c57ef	GET /api/v1/consultations/patient/43cefa78-2ba1-479e-b174-b69e044c57ef	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:31.171
62c8ce3c-d2bb-4459-adbd-7538700a021f	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:34.989
85a39809-c8e2-40fa-8181-60676e006ca8	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:40.921
ff1b4651-1ecb-49f4-a56b-f3490f236246	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Consultation	43cefa78-2ba1-479e-b174-b69e044c57ef	GET /api/v1/consultations/patient/43cefa78-2ba1-479e-b174-b69e044c57ef	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:43.565
b78eb31b-97df-46ba-9432-1dcd500b4456	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Patient	N/A	GET /api/v1/patients	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:50.765
f2ebc497-8bcc-40da-bfdd-a37c48d037cd	baa93f13-d57f-421f-8235-40ec53b29bea	VIEW	Consultation	43cefa78-2ba1-479e-b174-b69e044c57ef	GET /api/v1/consultations/patient/43cefa78-2ba1-479e-b174-b69e044c57ef	192.168.1.183	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	2026-03-05 22:25:50.766
\.


--
-- Data for Name: Consultation; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."Consultation" (id, "patientId", "therapistId", "sessionDate", "consultReason", intervention, agreements, "nextSessionDate", "sessionType", version, "previousVersionId", "isCorrected", "createdAt") FROM stdin;
13243d5a-ccbf-4047-85e3-fcd78892d3bf	f52e851d-0603-4de0-8277-d3f49ff10246	baa93f13-d57f-421f-8235-40ec53b29bea	2026-03-05 00:00:00	Ansiedad generalizada y dificultades para dormir	Psicoeducación sobre ansiedad, técnicas de respiración	Practicar respiración diafragmática 10 min diarios	2026-03-12 00:00:00	IN_PERSON	1	\N	f	2026-03-05 13:49:10.626
922d720d-5df5-4867-9700-50ea5f4a43f2	43cefa78-2ba1-479e-b174-b69e044c57ef	baa93f13-d57f-421f-8235-40ec53b29bea	2026-03-05 00:00:00	sensación de incomodidad y ansiedad	Respiración consciente	Relajarse	2026-03-12 00:00:00	TELEMED	1	\N	f	2026-03-05 15:03:20.055
\.


--
-- Data for Name: Patient; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."Patient" (id, "fullName", rut, "birthDate", occupation, address, phone, email, "emergencyContactName", "emergencyContactPhone", "treatingPsychiatrist", "treatingDoctor", "isActive", "deletedAt", "createdAt", "updatedAt", "consentSigned", "telemedConsentSigned", "therapistId") FROM stdin;
f52e851d-0603-4de0-8277-d3f49ff10246	María González Pérez	12.345.678-9	1990-05-15 00:00:00	Profesora	\N	+56912345678	maria@email.com	Juan González	+56987654321	\N	\N	t	\N	2026-03-05 13:38:00.162	2026-03-05 13:38:00.162	t	f	baa93f13-d57f-421f-8235-40ec53b29bea
43cefa78-2ba1-479e-b174-b69e044c57ef	Juan José Martínez Correa	17.661.989-9	1990-08-02 00:00:00	Developer	Los Escritores 10415	+56956039666	jmartinezc.cp@gmail.com	Marina Vera	+56 9 3706 2554	-		t	\N	2026-03-05 14:59:35.977	2026-03-05 14:59:35.977	t	t	baa93f13-d57f-421f-8235-40ec53b29bea
fd5ef203-02a1-48fb-8bb3-2870633d6ec8	Paciente Prueba	9.876.543-1	1990-01-01 00:00:00	Prueba	Direccion 123	+56912341234	correo@correo.cl	Contacto	+5644448888	-		t	\N	2026-03-05 15:01:47.59	2026-03-05 15:01:47.59	t	t	baa93f13-d57f-421f-8235-40ec53b29bea
\.


--
-- Data for Name: PatientDocument; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."PatientDocument" (id, "patientId", type, "fileName", "storagePath", "uploadedAt", "uploadedBy") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public."User" (id, email, "passwordHash", name, role, "mfaSecret", "mfaEnabled", "createdAt", "updatedAt", "deletedAt") FROM stdin;
baa93f13-d57f-421f-8235-40ec53b29bea	admin@umbral.cl	$argon2id$v=19$m=65536,t=3,p=4$CVmVdgewjSq5Buq+frF2aA$GQ2hqq0Qs9wFZLEG3pBZbtdbNzkIXdvNJt2tWrr+Vn4	Administrador Umbral	ADMIN	FFUUYLBTORKTGOLZHI3CKVSDNM3FIJDX	t	2026-03-05 13:12:02.357	2026-03-05 22:18:40.665	\N
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: umbral_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
3e319d17-bffa-40ec-8df2-b0c5a817f8ea	1c734e4e9677154f01f7ae28be0471607f774ac0367e366f6cc1bd029b52863c	2026-03-05 09:39:50.283315-03	20260305123950_init	\N	\N	2026-03-05 09:39:50.234562-03	1
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Consultation Consultation_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Consultation"
    ADD CONSTRAINT "Consultation_pkey" PRIMARY KEY (id);


--
-- Name: PatientDocument PatientDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."PatientDocument"
    ADD CONSTRAINT "PatientDocument_pkey" PRIMARY KEY (id);


--
-- Name: Patient Patient_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Patient_rut_key; Type: INDEX; Schema: public; Owner: umbral_user
--

CREATE UNIQUE INDEX "Patient_rut_key" ON public."Patient" USING btree (rut);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: umbral_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Consultation Consultation_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Consultation"
    ADD CONSTRAINT "Consultation_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Consultation Consultation_therapistId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Consultation"
    ADD CONSTRAINT "Consultation_therapistId_fkey" FOREIGN KEY ("therapistId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PatientDocument PatientDocument_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."PatientDocument"
    ADD CONSTRAINT "PatientDocument_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Patient Patient_therapistId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: umbral_user
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_therapistId_fkey" FOREIGN KEY ("therapistId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict k29X0byOep5upk9izSFmDPZI9NGI1gWYrAu6joR5ZOZY6fQjxooLuOC0hQeSCMf

